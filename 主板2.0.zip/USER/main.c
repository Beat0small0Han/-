#include "stm32f10x.h"
#include "usart1.h"
#include "usart2.h"
#include "zigbee.h"
#include "esp8266.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "delay.h"
#include "timer.h"


int main()
{
	u8 key;
	u8 status;
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //�жϷ���
	
	delay_init();
	uart_init(115200);
	usart3_init(115200);
	KEY_Init();
	LCD_Init();
	ask_zigbee();
	LCD_ShowString(0,50, 200, 30, 16, "zigbee-mode connected"); 
	esp8266_init();
	TIM3_Int_Init(9999,7199);  //1s
	
	
//	while(1){
//		key = KEY_Scan(0);
//		switch(key){               //��ʱ���������������Ժ�ϣ�����Ա��һ����������ʱ�䳤������
//			case WKUP_PRES:{
//				connect_to_wifi();
//				break;
//			}
//				
//			case KEY2_PRES:{
//				status = add_slave();
//				break;
//			}
//			
//			case KEY1_PRES:{
//				atk_8266_send_cmd("AT+CIPSTART=\"TCP\",\"192.168.43.136\",8085","CONNECT",400);
//				mqtt_connect();
//			}
//			
//			default:
//				break;
//		}
//	}
	
//	while(1){
//		if(!key_press){
//			if(WKUP_PRES == KEY_Scan(1)){
//				key_press = 1;
//				TIM_Cmd(TIM3, ENABLE);
//			}
//		}
//		
//		switch(key_event){
//			case 0x01:{
//				status = add_slave();
//				key_event = 0;
//				break;
//			}
//			case 0x02:{
//				connect_to_wifi();
//				key_event = 0;
//				break;
//			}
//			default:
//				break;
//		}	
//	}
	add_slave();
}
